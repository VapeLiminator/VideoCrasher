Please don't forget that the program is not finished.

If it's possible, I would like for people to NOT "steal" my project, as if to change the name of the creator, aka: me.

To open it, please open "VideoCrasher.exe"
The code isn't obfuscated, and you can see it has nothing malicious.
The code isn't open source just because i'm lazy, but if someone doesn't trust me, I'll be able to send source code.

Auto-Update is finally done.


Copyright 2022.
made by NeumaticYT#6969